#!/usr/bin/env bash
mongo < ./../db.sh
npm start