#!/usr/bin/env bash
rm -rf node_modules/bcrypt
npm install